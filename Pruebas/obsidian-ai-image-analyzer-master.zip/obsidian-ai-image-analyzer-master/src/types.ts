export type AnalyzedText = {
	path: string;
	text: string;
	libVersion: string;
};
